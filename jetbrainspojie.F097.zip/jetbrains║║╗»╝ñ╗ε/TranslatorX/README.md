本项目作为 [pingfangx/TranslatorX](https://www.pingfangx.com/xx/translation/jetbrains) 的一个子模块  
仅用于发布 JetBrains 系列软件的汉化包。  
因为汉化包为 jar 包，文件较大，不利于在版本仓库中维护，  
还经常传不上去、下不下来，因此单独作为一个仓库。  

查看源码、反馈问题等请查看 [主项目](https://www.pingfangx.com/xx/translation/jetbrains)  
使用帮助、常见问题、wiki 请查看 [wiki](https://www.pingfangx.com/xx/translation/jetbrains/usage)  
支持作者、赞助咖啡请点击[支持作者](https://www.pingfangx.com/xx/translation/jetbrains/feedback/support)